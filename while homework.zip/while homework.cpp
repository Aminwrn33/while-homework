﻿#include <iostream>

using namespace std;

int main()
{


	cout << "---tapsiriq 3---\n\n";
	int number = 2;

	do
	{
		cout << number << " ";
		number += 2;


	} while (number <= 50);

	cout << "\n\n";

	cout << "---tapsiriq 14---\n\n";

	srand(time(0));

	int myNumber;

	cout << "Seciminizi daxil edin:" << endl;
	cin >> myNumber;

	int compnumber = 0;
	int comptry = 0;

	while (myNumber != compnumber)
	{
		compnumber = rand() % 100;
		comptry++;
	}
	cout << "Cavabi tapdiniz!  Duzgun cavab: " << compnumber;

	cout << "\n\n";

	cout << "---tapsiriq 5---\n\n";

	int num = 3;
	do
	{
		cout << num << " ";
		num += 3;
	} while (num <= 100);

	cout << "\n\n";












}